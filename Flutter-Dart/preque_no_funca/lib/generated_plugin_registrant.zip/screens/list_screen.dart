import 'package:flutter/material.dart';

import '../widgets/despeses_llista.dart';

class DespesesScreen extends StatelessWidget {
  const DespesesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DespesesTitles();
  }
}
